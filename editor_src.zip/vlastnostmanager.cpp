#include "vlastnostmanager.h"

VlastnostManager::VlastnostManager()
{

}
