#include "dojbodovynastroj.h"

using namespace Nastroje;

DojbodovyNastroj::DojbodovyNastroj()
{
}


DojbodovyNastroj::~DojbodovyNastroj()
{
}